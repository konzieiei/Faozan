ผู้พัฒนาโครงงาน
1. นางสาวธัญจิรา สุกกรี
2. นางสาวมนัสนันท์ วัฒนสกลพันธุ์

วิชาการปฏิบัติการทางวิศวกรรมคอมพิวเตอร์ ภาควิชาวิศวกรรมคอมพิวเตอร์ คณะวิศวกรรมศาสตร์ มหาวิทยาลัยเกษตรศาสตร์

Projectนี้มีอยู่ 2 directoriesหลักๆคือ
        - Java เก็บ source code ที่เป็น gradle project
		- core 
		:: /src เก็บ codeหลักที่เป็น .java สำหรับการทำงานของเกมส์  
		:: /assets เก็บรูปภาพต่างๆที่ใช้ในเกมส์
		:: /lib เก็บไลบรารี่ต่างๆที่ใช้ใน เกมส์
		- desktop มี DesktopLauncher.java สำหรับกำหนดขนาดหน้าจอเพื่อทำงานบน desktop

	- Firmware เป็นโฟลเดอร์ที่เก็บcode ภาษาซี ที่ใช้ในการคอมไพล์ลงไปในpracticum board ที่ได้ทำเอาไว้ 

	และ schematic.pdf แสดงภาพผังวงจร



รายการอุปกรณ์ฮาร์ดแวร์ที่ใช้
1. Practicum Board สำหรับเป็นตัวควบคุม
2. Switch ใช้แทนสำหรับปุ่มกดในการเลือกคำตอบ
3. LED ใช้สำหรับเมื่อตอบคำถามเสร็จ ว่าผิดหรือถูก
4. Resistor เป็นตัวต้านทาน
5.BreadBoard
6.สายแพร ผู้-เมีย เมีย-เมีย

Project Creator
1. Thanjira Sukkree
2. Manussanun Wattanasakolphan

Practicum in Computer Engineering, Department of Computer Engineering, Faculty of Engineering, Kasetsart University

This project is two main folder in this file
 	- Java This folder contains all java source code
		-core
		:: /src contains java source code for game part
		:: /assets contains pictures used in game
		:: /lib contains all libraries used in game
		-desktop has DesktopLauncher.java for specifying game window size 

 	- Firmware
        	This folder contains all C source code for practicum board
	
	and schematic.pdf 



Hardware use in project

1. Practicum Board for controller
2. Switch for choose answer
3. used LED for showing the result
4. Resistor
5.BreadBoard
6.Pair male to male and female to male
