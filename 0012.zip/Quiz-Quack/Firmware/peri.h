#define IS_SWITCH1_PRESSED() ~(PINC |~(1 << 0))
#define IS_SWITCH2_PRESSED() ~(PINC |~(1 << 1))
#define IS_SWITCH3_PRESSED() ~(PINC |~(1 << 2))
#define IS_SWITCH4_PRESSED() ~(PINC |~(1 << 3))

#define IS_SWITCH1_PRESSED_B() ~(PINB |~(1 << 0))
#define IS_SWITCH2_PRESSED_B() ~(PINB |~(1 << 1))
#define IS_SWITCH3_PRESSED_B() ~(PINB |~(1 << 2))
#define IS_SWITCH4_PRESSED_B() ~(PINB |~(1 << 3))

void init_peripheral();
void set_led(uint8_t pin, uint8_t state);
void set_led_value(uint8_t value);
uint16_t read_adc(uint8_t channel);
uint16_t get_light();
