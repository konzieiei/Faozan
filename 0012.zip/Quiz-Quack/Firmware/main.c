#include <avr/io.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */
#include <avr/pgmspace.h>   /* required by usbdrv.h */

#include "peri.h"
#include "usbdrv.h"

#define RQ_GET_SWITCH1      1
#define RQ_GET_SWITCH2      2
#define RQ_GET_SWITCH3      3
#define RQ_GET_SWITCH4      4

#define RQ_GET_SWITCH1B      5
#define RQ_GET_SWITCH2B      6
#define RQ_GET_SWITCH3B      7
#define RQ_GET_SWITCH4B      8

#define RQ_SET_LED  9

#define LED_GREEN_B PD6
#define LED_RED_B PD5
#define LED_GREEN_A PD0
#define LED_RED_A PD1




/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */
usbMsgLen_t usbFunctionSetup(uint8_t data[8])
{
    usbRequest_t *rq = (void *)data;

    /* declared as static so they stay valid when usbFunctionSetup returns */
    static uint8_t switch_state;
    // static uint16_t light;
    if (rq->bRequest == RQ_SET_LED)
    {
        uint8_t led_val = rq->wValue.bytes[0];
        uint8_t led_no  = rq->wIndex.bytes[0];
        set_led(led_no, led_val);
    }

//
//     else if (rq->bRequest == RQ_GET_SWITCH)
//     {
//         switch_state = IS_SWITCH_PRESSED();
//
//         /* point usbMsgPtr to the data to be returned to host */
//         usbMsgPtr = &switch_state;
//
//         /* return the number of bytes of data to be returned to host */
//         return 1;
//     }
//     else if (rq->bRequest == RQ_SET_LED_VALUE){
// 		uint8_t led_val = rq->wValue.bytes[0];
// 		set_led_value( led_val);
// 		return 0;
// 	}
//     else if(rq->bRequest == RQ_GET_LIGHT){
// 	light = get_light();
// 	usbMsgPtr = &light;
// 	return 2;
// }
//     /* default for not implemented requests: return no data back to host */
    if(rq->bRequest == RQ_GET_SWITCH1) {
    switch_state = IS_SWITCH1_PRESSED();
    usbMsgPtr = &switch_state;
    //_delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH2) {
    switch_state = IS_SWITCH2_PRESSED()>>1;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH3) {
    switch_state = IS_SWITCH3_PRESSED()>>2;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH4) {
    switch_state = IS_SWITCH4_PRESSED()>>3;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }

    if(rq->bRequest == RQ_GET_SWITCH1B) {
    switch_state = IS_SWITCH1_PRESSED_B();
    usbMsgPtr = &switch_state;
    //_delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH2B) {
    switch_state = IS_SWITCH2_PRESSED_B()>>1;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH3B) {
    switch_state = IS_SWITCH3_PRESSED_B()>>2;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }
    if(rq->bRequest == RQ_GET_SWITCH4B) {
    switch_state = IS_SWITCH4_PRESSED_B()>>3;
    usbMsgPtr = &switch_state;
    // _delay_ms(10);
    return 1;
    }
  return 0;
}

/* ------------------------------------------------------------------------- */
int main(void)
{
    init_peripheral();

    usbInit();

    /* enforce re-enumeration, do this while interrupts are disabled! */
    usbDeviceDisconnect();
    _delay_ms(300);
    usbDeviceConnect();

    /* enable global interrupts */
    sei();

    /* main event loop */
    for(;;)
    {
        usbPoll();
    }

    return 0;
}

/* ------------------------------------------------------------------------- */
